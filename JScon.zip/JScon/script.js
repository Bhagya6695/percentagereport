// You can add your codes here 
function report()
{

    var studname=document.querySelector("#name").value;
    var studclass=document.querySelector("#class").value;
    var studroll=document.querySelector("#rollNo").value;
    var mark1 = parseInt(document.getElementById("mark1").value);
    var mark2 = parseInt(document.getElementById("mark2").value);
    var mark3 = parseInt(document.getElementById("mark3").value);
    var total = mark1+mark2+mark3;
    var per = (total/300)*100;
    var thala = document.querySelector("#head");
    var par = document.querySelector("#para");
    var divu = document.querySelector("#mydiv");
    var average = document.querySelector("#avg");

    //alert("hi\n"+studname+"\nscores\n"+per+"%");
    mydiv.style.border = "solid red 4px";
    mydiv.style.backgroundColor ="orange";
    mydiv.style.padding="5%";
    

    thala.innerText="Percentage Card";
    par.innerText="The percentage obtained by your ward  " + studname + " of Class " +studclass + " with RollNo : " + studroll + " has scored ";
    average.innerText= per+"%";

    if(per<40)
    { average.style.color="red"; }
    else if(per<70){
        average.style.color="green";
    }
    else
    { average.style.color="white";
    
    
}

}